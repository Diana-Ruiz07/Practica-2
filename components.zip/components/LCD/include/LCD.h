#ifndef LCD_H
#define LCD_H

#include <stdio.h>
#include <stdint.h>
#include "esp_err.h"
#include "driver/i2c.h"

// --- Dirección y puerto I2C ---
#define LCD_ADDR 0x27
#define I2C_PORT I2C_NUM_0

// --- Pines I2C (ajusta según tu hardware) ---
#define SDA_PIN 33
#define SCL_PIN 32

// --- Comandos LCD ---
#define LCD_CMD_CLEAR        0x01
#define LCD_CMD_HOME         0x02
#define LCD_CMD_ENTRY_MODE   0x06
#define LCD_CMD_DISPLAY_ON   0x0C
#define LCD_CMD_FUNCTION_SET 0x28

// --- Funciones públicas ---
// Inicialización
void i2c_master_init(void);
void lcd_init(void);

// Operaciones básicas
void lcd_clear(void);
void lcd_set_cursor(uint8_t row, uint8_t col);
void lcd_puts(const char *str);

// Funciones internas
esp_err_t lcd_write_byte(uint8_t data);
esp_err_t lcd_send_nibble(uint8_t nibble, uint8_t rs);
esp_err_t lcd_send_byte(uint8_t byte, uint8_t rs);

#endif // LCD_H
