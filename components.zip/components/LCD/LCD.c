#include "LCD.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

// --- Enviar un byte al expansor I2C ---
esp_err_t lcd_write_byte(uint8_t data) {
    i2c_cmd_handle_t cmd = i2c_cmd_link_create();
    esp_err_t ret;

    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (LCD_ADDR << 1) | I2C_MASTER_WRITE, true);
    i2c_master_write_byte(cmd, data, true);
    i2c_master_stop(cmd);

    ret = i2c_master_cmd_begin(I2C_PORT, cmd, pdMS_TO_TICKS(1000));
    i2c_cmd_link_delete(cmd);
    vTaskDelay(pdMS_TO_TICKS(1));
    return ret;
}

// --- Enviar nibble (4 bits) ---
esp_err_t lcd_send_nibble(uint8_t nibble, uint8_t rs) {
    uint8_t data = (nibble & 0xF0) | (rs ? 0x01 : 0x00) | 0x08;

    esp_err_t ret = lcd_write_byte(data | 0x04); // Enable HIGH
    if (ret != ESP_OK) return ret;

    ret = lcd_write_byte(data & ~0x04); // Enable LOW
    vTaskDelay(pdMS_TO_TICKS(2));
    return ret;
}

// --- Enviar byte completo ---
esp_err_t lcd_send_byte(uint8_t byte, uint8_t rs) {
    esp_err_t ret = lcd_send_nibble(byte & 0xF0, rs);
    if (ret != ESP_OK) return ret;
    return lcd_send_nibble((byte << 4) & 0xF0, rs);
}

// --- Inicializar LCD ---
void lcd_init(void) {
    vTaskDelay(pdMS_TO_TICKS(50));
    lcd_send_nibble(0x30, 0);
    vTaskDelay(pdMS_TO_TICKS(5));
    lcd_send_nibble(0x30, 0);
    vTaskDelay(pdMS_TO_TICKS(1));
    lcd_send_nibble(0x30, 0);
    vTaskDelay(pdMS_TO_TICKS(10));
    lcd_send_nibble(0x20, 0); // Modo 4 bits

    lcd_send_byte(LCD_CMD_FUNCTION_SET, 0);
    lcd_send_byte(LCD_CMD_DISPLAY_ON, 0);
    lcd_send_byte(LCD_CMD_CLEAR, 0);
    lcd_send_byte(LCD_CMD_ENTRY_MODE, 0);

    vTaskDelay(pdMS_TO_TICKS(2));
}

// --- Borrar pantalla ---
void lcd_clear(void) {
    lcd_send_byte(LCD_CMD_CLEAR, 0);
    vTaskDelay(pdMS_TO_TICKS(2));
}

// --- Posicionar cursor ---
void lcd_set_cursor(uint8_t row, uint8_t col) {
    // ⚠️ Ajusta según tu pantalla: prueba primero {0x00, 0x40}, si se enciman usa {0x00, 0x14}
    uint8_t row_offsets[] = {0x00, 0x40};
    if (row > 1) row = 1;  
    lcd_send_byte(0x80 | (col + row_offsets[row]), 0);
}

// --- Escribir texto ---
void lcd_puts(const char *str) {
    while (*str) {
        lcd_send_byte(*str++, 1);
    }
}

// --- Inicializar I2C ---
void i2c_master_init(void) {
    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = SDA_PIN,
        .scl_io_num = SCL_PIN,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = 100000,
    };
    i2c_param_config(I2C_PORT, &conf);
    i2c_driver_install(I2C_PORT, conf.mode, 0, 0, 0);
}
