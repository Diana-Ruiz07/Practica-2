#include <stdio.h>
#include <stdlib.h>
#include "driver/gpio.h"
#include <stdbool.h>   
#include "teclado_4x4.h"
#include "esp_rom_sys.h"
#include "esp_task_wdt.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
char input[num_caracteres]={0};

char teclado[filas][columnas] = {
    { '1', '2', '3', 'A' },
    { '4', '5', '6', 'B' },
    { '7', '8', '9', 'C' },
    { '*', '0', '#', 'D' }
};
void iniciar_teclado() {
    for (int i = 0; i < columnas; i++) {
        gpio_reset_pin(pinfilas[i]);
        gpio_set_direction(pinfilas[i], GPIO_MODE_OUTPUT);
        gpio_set_level(pinfilas[i], 1);
    }

    for (int i = 0; i < filas; i++) {
        gpio_reset_pin(pincolumnas[i]);
        gpio_set_direction(pincolumnas[i], GPIO_MODE_INPUT);
        gpio_set_pull_mode(pincolumnas[i], GPIO_PULLUP_ONLY);
    }
}
/*void leer_teclado_numeros() {
    int caracteres_usados = 0;
    bool enter = false;

    while (!enter) {
        esp_task_wdt_reset();  // alimentar el WDT

        for (int f = 0; f < filas; f++) {
            gpio_set_level(pinfilas[f], 0);

            for (int c = 0; c < columnas; c++) {
                if (gpio_get_level(pincolumnas[c]) == 0) {
                    // debounce: espera 20ms
                    vTaskDelay(pdMS_TO_TICKS(20));

                    if (gpio_get_level(pincolumnas[c]) == 0) {
                        char tecla = teclado[f][c];

                        // esperar hasta que se suelte la tecla
                        while (gpio_get_level(pincolumnas[c]) == 0) {
                            vTaskDelay(pdMS_TO_TICKS(5));
                            esp_task_wdt_reset();
                        }
                        printf("Tecla detectada: %c (fila=%d, col=%d)\n", tecla, f, c);

                        if (tecla == '*') {  // Enter
                            printf("enter");
                            enter = true;
                            break;
                        }
                        if (tecla == '#') {  // Borrar
                            if (caracteres_usados > 0) {
                                caracteres_usados--;
                                input[caracteres_usados] = '\0';
                                printf("Eliminado. Actual: %s\n", input);
                            }
                            continue;
                        }

                        if (tecla >= '0' && tecla <= '9') {
                            if (caracteres_usados < num_caracteres - 1) {
                                input[caracteres_usados++] = tecla;
                                input[caracteres_usados] = '\0';
                                printf("Texto actual: %s\n", input);
                            }
                        }
                    }
                }
            }
            gpio_set_level(pinfilas[f], 1);
        }
        vTaskDelay(pdMS_TO_TICKS(10)); // da respiro al scheduler
    }
}*/
void borrar_input(){
    input[0] = '\0';  // marca el string como vacío
}

bool detectar_tecla(char tecla) {
    for (int fila = 0; fila < filas; fila++) {
        gpio_set_level(pinfilas[fila], 0);
        for (int col = 0; col < columnas; col++) {
            if (gpio_get_level(pincolumnas[col]) == 0) {
                if (teclado[fila][col] == tecla) {
                    gpio_set_level(pinfilas[fila], 1);
                    return true;   // Se encontró la tecla
                }
            }
        }
        gpio_set_level(pinfilas[fila], 1);
    }
    return false;   // 👈 No se encontró la tecla
}
char leer_teclado() {
    while (1) {
        esp_task_wdt_reset();  // alimentar el WDT

        for (int f = 0; f < filas; f++) {
            gpio_set_level(pinfilas[f], 0);

            for (int c = 0; c < columnas; c++) {
                if (gpio_get_level(pincolumnas[c]) == 0) {
                    // debounce: espera 20ms
                    vTaskDelay(pdMS_TO_TICKS(20));

                    if (gpio_get_level(pincolumnas[c]) == 0) {
                        char tecla = teclado[f][c];

                        // esperar hasta que se suelte la tecla
                        while (gpio_get_level(pincolumnas[c]) == 0) {
                            vTaskDelay(pdMS_TO_TICKS(5));
                            esp_task_wdt_reset();
                        }

                        printf("Tecla detectada: %c (fila=%d, col=%d)\n", tecla, f, c);
                        gpio_set_level(pinfilas[f], 1);
                        return tecla;  // ← devuelve la tecla inmediatamente
                    }
                }
            }
            gpio_set_level(pinfilas[f], 1);
        }
        vTaskDelay(pdMS_TO_TICKS(10)); // da respiro al scheduler
    }
}
void leer_teclado_numeros() {
    int pos = 0;

    while (1) {
        char tecla = leer_teclado();  // espera tecla

        if (tecla == '*') {  // Enter
            input[pos] = '\0';
            break;
        }

        if (tecla == '#') {  // borrar
            if (pos > 0) {
                pos--;
                input[pos] = '\0';
            }
            continue;
        }

        if (tecla == 'D') {  // parada
            input[0] = '\0';   // vacío
            break;
        }

        if (tecla >= '0' && tecla <= '9') {
            if (pos < num_caracteres - 1) {
                input[pos++] = tecla;
                input[pos] = '\0';
            }
        }
    }
}
