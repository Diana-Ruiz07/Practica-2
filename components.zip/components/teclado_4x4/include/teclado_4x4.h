#define num_caracteres 10   // Número máximo de caracteres a leer en el teclado
#define filas 4
#define columnas 4
extern char input[num_caracteres];
extern char teclado[filas][columnas];
extern int pinfilas[filas];
extern int pincolumnas[columnas];

void iniciar_teclado();
void leer_teclado_numeros();
void borrar_input();
bool detectar_tecla(char tecla);