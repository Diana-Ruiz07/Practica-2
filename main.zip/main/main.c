#include <stdio.h>
#include "driver/dac_oneshot.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "teclado_4x4.h"
#include "string.h"
#include "esp_task_wdt.h"
#include "LCD.h"
#include "esp_adc/adc_oneshot.h"
#include <stdlib.h>


extern int pinfilas[filas]     = {14,27,26,23};
extern int pincolumnas[columnas] = {21,19,18,5};
extern char input[num_caracteres];

int entrada_cruda=0;
int RPM=0;
float Vref = 1.1;     // voltaje de referencia ADC
int control = 0;       // valor inicial DAC
float voltaje_salida;
// ejemplo IDF: desactivar pulls y forzar entrada

adc_oneshot_unit_handle_t adc_handle;
adc_oneshot_unit_init_cfg_t init_cfg = {
    .unit_id = ADC_UNIT_2,
};

// 2. Configurar canal (ancho de resolución de 12 bits, atenuación de 11dB para medir hasta 3.3V)
adc_oneshot_chan_cfg_t chan_cfg = {
    .bitwidth = ADC_BITWIDTH_12,
    .atten = ADC_ATTEN_DB_0,
};

dac_oneshot_handle_t salida;

dac_oneshot_config_t cfg={
    .chan_id=DAC_CHAN_0,        // pin 25
};

#define N_MEDIAS 4
static int buffer_adc[N_MEDIAS] = {0};
static int idx = 0;
float vcc=12.08;
float c1=0.0000000093;
float R1=9800;
float k=8;
void actualizar_rpm(void){
    int valor = 0;
    ESP_ERROR_CHECK(adc_oneshot_read(adc_handle, ADC_CHANNEL_5, &valor));
    buffer_adc[idx] = valor;
    idx = (idx + 1) % N_MEDIAS;

    int suma = 0;
    for (int i=0;i<N_MEDIAS;i++) suma += buffer_adc[i];
    entrada_cruda = suma / N_MEDIAS;
    float voltaje = (entrada_cruda * Vref) / 4095.0f;
    float frecuencia = (voltaje)/(vcc*c1*R1*k);
    RPM = (60.0f / 20.0f) * frecuencia;
    //printf("frecuencia: %.3f\n",frecuencia);
    printf("RPM: %.i\n",RPM);
    //printf("voltaje: %.3f\n",voltaje);
    //printf("entradac cruda: %.i\n",entrada_cruda);
}



void cambiar_salida(int entrada){
    if (entrada > 255) entrada = 255;
    if (entrada < 0) entrada = 0;
    control = entrada;
    ESP_ERROR_CHECK(dac_oneshot_output_voltage(salida, entrada));
}

static bool mostrar_adc = false;  // variable estática para alternar
void mostrar_datos_lcd(int ref, int act, int dac_out) {
    char buffer[17]; // 16 chars + null terminator

    // Fila 0
    lcd_set_cursor(0,0);
    snprintf(buffer, sizeof(buffer), "Ref:%3d Act:%3d", ref, act);
    lcd_puts(buffer);

    // Fila 1
    lcd_set_cursor(1,0);
    snprintf(buffer, sizeof(buffer), "ADC:%4d D:%3d", entrada_cruda, dac_out);
    lcd_puts(buffer);
}

void app_main(void)
{
    // registrar esta tarea en el WDT
    ESP_ERROR_CHECK(esp_task_wdt_add(NULL));
    ESP_ERROR_CHECK(dac_oneshot_new_channel(&cfg, &salida));        //crear la salida del dac Pin25
    ESP_ERROR_CHECK(adc_oneshot_new_unit(&init_cfg, &adc_handle));  //crear y configurar la entrada del Adc pin 34
    ESP_ERROR_CHECK(adc_oneshot_config_channel(adc_handle, ADC_CHANNEL_5, &chan_cfg));
    iniciar_teclado();
    i2c_master_init();  // SDA 32, SCL 33
    lcd_init();

    int RPM_usuario = 0;
    int salida_dac = 100;
    float ganancia = 0.1;
    bool control_activo = false;

    while (1) {
        // ---- MENÚ INICIAL ----
        lcd_clear();
        lcd_set_cursor(0,0);
        lcd_puts("Elija las RPM()");
        lcd_set_cursor(1,0);
        lcd_puts("Max 200, Min 10");
        
        leer_teclado_numeros();
        RPM_usuario = atoi(input);   // ✅ ya no lo redeclaro

        control_activo = true;   // arranca el control después de digitar

        // ---- BUCLE DE CONTROL ----
        while (control_activo) {
            cambiar_salida(salida_dac);
            actualizar_rpm();

            int error = RPM_usuario - RPM;
            if (abs(error) > 5) {
                salida_dac += ganancia * error;

                // saturación
                if (salida_dac > 255) salida_dac = 255;
                if (salida_dac < 0)   salida_dac = 0;

                cambiar_salida(salida_dac);
            }

            // ✅ Mostrar en LCD sin borrar todo
            mostrar_datos_lcd(RPM_usuario, RPM, salida_dac);

            // vigilar si presiona D para detener
            if (detectar_tecla('D')) {
                control_activo = false;
                cambiar_salida(0);
                printf("Control detenido por tecla D\n");
            }

            vTaskDelay(pdMS_TO_TICKS(200));   // refresco más suave
            ESP_ERROR_CHECK(esp_task_wdt_reset());
        }
    }
}
